from .colored_logger import setup_logger

logger = setup_logger()
