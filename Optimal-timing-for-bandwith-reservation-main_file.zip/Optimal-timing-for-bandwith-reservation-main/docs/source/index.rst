.. Optimal timing for bandwith reservation documentation master file, created by
   sphinx-quickstart on Fri Mar 17 22:03:41 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Optimal timing for bandwith reservation's documentation!
===================================================================

.. toctree::
   :maxdepth: 8
   :caption: Contents:

   installation
   usage
   models
   trainer
   utils
   visualisations
   paper
   plot
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`