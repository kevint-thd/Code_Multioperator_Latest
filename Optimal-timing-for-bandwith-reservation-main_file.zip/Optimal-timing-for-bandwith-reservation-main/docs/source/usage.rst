Usage
=====

To use the Optimal timing for bandwith reservation models,

run

`cd repo_location/optimal_timing_for_bandwidth_reservation && poerty run python paper.py`

The data used for training can be provided in the optimal_timing_for_bandwidth_reservation/resources directory.


To run the `plot.py` script to see the plots

run 

`cd repo_location/optimal_timing_for_bandwidth_reservation && poerty run python plot.py`