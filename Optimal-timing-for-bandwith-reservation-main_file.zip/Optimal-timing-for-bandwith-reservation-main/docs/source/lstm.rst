LSTM
====================

.. automodule:: models.lstm
   :members:
   :undoc-members:
   :show-inheritance:
   