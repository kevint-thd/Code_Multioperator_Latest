Trainer
=========

.. automodule:: trainers.trainer
   :members:
   :undoc-members:
   :show-inheritance: