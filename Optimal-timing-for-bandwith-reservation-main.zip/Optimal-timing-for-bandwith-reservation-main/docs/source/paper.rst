Paper
=========

.. automodule:: paper
   :members:
   :undoc-members:
   :show-inheritance: