Installation
============

To install the Strapi Profairs Synchroniser, follow these steps:

1. Download the code from the repository: 
2. Install the dependencies using Poetry: `poetry install`
3. To run the script see the usage section.
