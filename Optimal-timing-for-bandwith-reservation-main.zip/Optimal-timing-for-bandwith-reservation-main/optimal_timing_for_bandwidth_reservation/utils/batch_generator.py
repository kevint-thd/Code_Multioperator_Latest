import torch
from typing import List, Tuple
from config import device

class BatchGenerator:
    """
    A generator that provides batches of input and target data.

    Args:
        data (List[Tuple[torch.Tensor, torch.Tensor]]): The input and target data to batch.
        batch_size (int): The size of each batch.

    Attributes:
        data (List[Tuple[torch.Tensor, torch.Tensor]]): The input and target data.
        batch_size (int): The size of each batch.
        num_batches (int): The total number of batches.

    """

    def __init__(self, data: List[Tuple[torch.Tensor, torch.Tensor]], batch_size: int):
        self.data = data
        self.batch_size = batch_size
        self.num_batches = len(data) // batch_size  # Calculate the number of full batches
        if len(data) % batch_size != 0:
            self.num_batches += 1  # Add one more batch for any remaining data
        self.device = device

    def __len__(self) -> int:
        """
        Returns the total number of batches.
        """
        return self.num_batches

    def __iter__(self):
        self.idx = 0
        return self

    def __next__(self) -> Tuple[torch.Tensor, torch.Tensor]:
        if self.idx >= self.num_batches:
            raise StopIteration("End of data batches reached")

        start_idx = self.idx * self.batch_size
        end_idx = min((self.idx + 1) * self.batch_size, len(self.data))

        batch_data = self.data[start_idx:end_idx]

        batch_inputs, batch_targets = zip(*batch_data)

        batch_inputs = torch.stack(batch_inputs).to(self.device)
        batch_targets = torch.stack(batch_targets).to(self.device)

        self.idx += 1

        # Debugging statements
        print(f"Batch {self.idx}/{self.num_batches}")
        print(f"Batch input shape: {batch_inputs.shape}")
        print(f"Batch target shape: {batch_targets.shape}")

        return batch_inputs, batch_targets

