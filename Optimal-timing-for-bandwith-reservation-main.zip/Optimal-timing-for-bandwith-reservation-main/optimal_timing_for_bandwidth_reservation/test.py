print("Hello, Python!")
